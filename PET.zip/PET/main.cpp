#include "cabecalho.h"

void ler_dados(const char* arq) {
    FILE* f = fopen(arq, "r");

    fscanf(f, "%d %d %d", &num_tarefas, &temp_normal_trab, &temp_max_trab);
    for (int i = 0; i < num_tarefas; i++) {
        fscanf(f, "%d %d", &vet_h_ini_tarefa[i], &vet_h_term_tarefa[i]);
    }

    fclose(f);
}

void criar_solucao(Solucao& sol) {
    int trip = 0;
    sol.num_trip = num_tarefas / 2;

    for (int i = 0; i < num_tarefas; i++) {
        for (int j = 0; j < teste; j++) {
            trip = rand() % sol.num_trip;
            sol.mat_sol[trip][i] = j; 
            
        }
    }
}

int main () {
    Solucao* sol;
    
    ler_dados("csp25.txt");
    criar_solucao(*sol);

    printf("%d \n", sol->num_trip);
    
    for (int i = 0; i < sol->num_trip; i++) {
        printf("%d ", sol->vet_num_tarefas_trip[i]);
    }

    return 0;
}