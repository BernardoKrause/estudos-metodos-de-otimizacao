#ifndef CABECALHO_H
#define CABECALHO_H

#include "stdio.h"
#include "stdlib.h"

#define MAX_TAREFAS 500
#define MAX_TRIPULACOES 400

// valores referentes a tempo estão expressos em minutos

int num_tarefas = 0;
int temp_normal_trab; // tempo de duração de um turno sem horas extras
int temp_max_trab; // tempo limite de duração de um turno incluido horas extras
int vet_h_ini_tarefa[MAX_TAREFAS];
int vet_h_term_tarefa[MAX_TAREFAS];

const int vet_pen[4] = {1,1,100,100};

typedef struct tSolucao {
    int num_trip; // o problema de tentar encontrar o número mínimo de tripulações para realizar as tarefas
    int vet_num_tarefas_trip[MAX_TRIPULACOES];
    int mat_sol[MAX_TRIPULACOES][MAX_TAREFAS]; // linha representa a tripulação e a coluna as tarefas 
    int fo;

    int vet_he[MAX_TRIPULACOES]; // horas extras
    int vet_to[MAX_TRIPULACOES]; // tempo ocioso
    int vet_ts[MAX_TRIPULACOES]; // tempo de sobreposição
    int vet_te[MAX_TRIPULACOES]; // tsempo excessivo
} Solucao;

void ler_dados(char* arq);
void criar_solucao(Solucao& sol);
void calc_fo(Solucao& sol);
void clonar_solucao(Solucao& sol);

#endif